USE world;

--  Query #5 --

SELECT 
    name, surface_area, population
FROM
    countries
WHERE
    surface_area < 501
        AND population > 100000;